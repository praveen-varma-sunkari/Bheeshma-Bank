import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Smartphone, CheckCircle2, 
  AlertCircle, ArrowRight, ArrowLeft, Sparkles, User, Mail, 
  RefreshCw, KeyRound, Eye, EyeOff, Lock
} from 'lucide-react';
import { 
  findUserByPhone, registerUserInStore, normalizePhone, 
  createWebsiteSession, addAdminRequest, getAdminRequests, updateUserInStore, getStoredUsers 
} from '../data/mockData';

export const AuraWelcomeAuth = ({ onLoginSuccess, currentLoggedInUser, onCancel, sessionExpiredNotice }) => {
  const [stage, setStage] = useState(sessionExpiredNotice ? 'phone_lookup' : 'welcome');
  
  const [countryCode, setCountryCode] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState(sessionExpiredNotice?.phone || '');
  const [isSearchingPhone, setIsSearchingPhone] = useState(false);
  const [matchedUser, setMatchedUser] = useState(null);
  const [phoneLookupError, setPhoneLookupError] = useState('');

  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const [resetRequestId, setResetRequestId] = useState(null);
  const [resetPinInput, setResetPinInput] = useState('');
  const [newResetPassword, setNewResetPassword] = useState('');
  const [resetError, setResetError] = useState('');
  const [resetSuccess, setResetSuccess] = useState('');

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [formTouched, setFormTouched] = useState({});
  const [regError, setRegError] = useState('');

  const checks = {
    fullName: {
      isValid: formData.fullName.trim().split(' ').length >= 2 && formData.fullName.length >= 4,
      message: formData.fullName.trim().split(' ').length >= 2 ? "Verified legal name format" : "Please enter first and last name"
    },
    email: {
      isValid: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email),
      message: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email) ? "Valid email domain format" : "Enter a valid personal or enterprise email"
    },
    password: {
      isValid: formData.newPassword.length >= 6,
      message: formData.newPassword.length >= 6 ? "Strong cryptographic key" : "Must be at least 6 characters"
    },
    confirmPassword: {
      isValid: formData.confirmPassword.length >= 6 && formData.confirmPassword === formData.newPassword,
      message: formData.confirmPassword === formData.newPassword && formData.confirmPassword.length >= 6 ? "Passwords match" : "Passwords must match"
    }
  };

  const isFormFullyValid = checks.fullName.isValid && checks.email.isValid && checks.password.isValid && checks.confirmPassword.isValid;

  useEffect(() => {
    if (stage === 'forgot_password' && resetRequestId && !resetPinInput) {
      const interval = setInterval(async () => {
        const reqs = await getAdminRequests();
        const myReq = reqs.find(r => r.id === resetRequestId);
        if (myReq && myReq.status === 'PIN_GENERATED' && myReq.generatedPin) {
          setResetPinInput(myReq.generatedPin);
        }
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [stage, resetRequestId, resetPinInput]);

  const handleCheckPhoneNumber = (e) => {
    if (e) e.preventDefault();
    const rawNumber = `${countryCode} ${phoneNumber}`.trim();
    const cleanDigits = normalizePhone(rawNumber);

    if (cleanDigits.length < 7) {
      setPhoneLookupError("Please enter a valid phone number.");
      return;
    }

    setPhoneLookupError('');
    setIsSearchingPhone(true);

    setTimeout(async () => {
      setIsSearchingPhone(false);
      const user = await findUserByPhone(rawNumber);
      if (user) {
        if (user.accountStatus === 'DELETED') {
          setPhoneLookupError("your account was permanently deleted by the aura authorities. for any queries reach nearest aura bank");
          return;
        }
        setMatchedUser(user);
        setPasswordInput('');
        setLoginError('');
        setStage('enter_password');
      } else {
        setMatchedUser(null);
        setFormData({ fullName: '', email: '', newPassword: '', confirmPassword: '' });
        setRegError('');
        setStage('create_profile');
      }
    }, 600);
  };

  const handlePasswordSubmit = (e) => {
    if (e) e.preventDefault();
    if (!passwordInput.trim()) {
      setLoginError("Please enter your password");
      return;
    }

    setIsAuthenticating(true);
    setLoginError('');

    setTimeout(() => {
      setIsAuthenticating(false);
      if (passwordInput === matchedUser.password) {
        if (matchedUser.sessionId && matchedUser.sessionId !== "null") {
          setStage('multi_device_prompt');
        } else {
          createWebsiteSession(matchedUser);
          onLoginSuccess(matchedUser);
        }
      } else {
        setLoginError("Incorrect password. Please verify and try again.");
      }
    }, 500);
  };

  const handleForgotPassword = async () => {
    const reqs = await getAdminRequests();
    const existingReq = reqs.find(r => r.type === 'FORGOT_CREDENTIALS' && r.userPhone === matchedUser.phone && (r.status === 'PENDING' || (r.status === 'PIN_GENERATED' && r.expiresAt > Date.now())));
    
    if (existingReq) {
      setResetRequestId(existingReq.id);
      setStage('forgot_password');
      setResetError('');
      setResetSuccess('');
      setResetPinInput(existingReq.generatedPin || '');
      return;
    }

    const req = {
      id: `req_${Date.now()}`,
      type: 'FORGOT_CREDENTIALS',
      userPhone: matchedUser.phone,
      userName: matchedUser.name,
      data: { type: 'Password' },
      timestamp: new Date().toISOString(),
      status: 'PENDING'
    };
    await addAdminRequest(req);
    setResetRequestId(req.id);
    setStage('forgot_password');
    setResetError('');
    setResetSuccess('');
  };

  const handleResetPasswordSubmit = async (e) => {
    if (e) e.preventDefault();
    setResetError('');
    const reqs = await getAdminRequests();
    const req = reqs.find(r => r.id === resetRequestId);
    
    if (!req) return setResetError("Request not found.");
    if (req.status !== 'PIN_GENERATED') return setResetError("Admin has not generated the PIN yet. Please wait.");
    if (Date.now() > req.expiresAt) return setResetError("PIN has expired (10 minutes limit).");
    if (req.generatedPin !== resetPinInput) return setResetError("Invalid PIN.");
    if (newResetPassword.length < 6) return setResetError("New password must be at least 6 characters.");

    if (req.data.type === 'MPIN') {
        await updateUserInStore({ ...matchedUser, mpin: newResetPassword });
        setResetSuccess("MPIN reset successfully. You can now use your new MPIN.");
    } else {
        await updateUserInStore({ ...matchedUser, password: newResetPassword });
        setResetSuccess("Password reset successfully. You can now log in.");
    }
    
    setTimeout(() => setStage('enter_password'), 2000);
  };

  const handleCreateProfileSubmit = async (e) => {
    e.preventDefault();
    setFormTouched({ fullName: true, email: true, newPassword: true, confirmPassword: true });
    
    if (!isFormFullyValid) {
      setRegError("Please resolve the errors above before continuing.");
      return;
    }
    
    setRegError('');
    setIsAuthenticating(true);

    const allUsers = await getStoredUsers();
    
    const emailExists = allUsers.some(u => u.email && u.email.toLowerCase() === formData.email.trim().toLowerCase());
    if (emailExists) {
        setRegError("Email already exists. Please provide a different email.");
        setIsAuthenticating(false);
        return;
    }

    const passwordExists = allUsers.some(u => u.password === formData.newPassword);
    if (passwordExists) {
        setRegError("Password already exists. Please choose a different password.");
        setIsAuthenticating(false);
        return;
    }

    await new Promise(r => setTimeout(r, 1500));
    const rawNumber = `${countryCode} ${phoneNumber}`.trim();
    const newUserId = `u_${Date.now()}`;
    const newUser = {
      id: newUserId,
      phone: rawNumber,
      normalizedPhone: normalizePhone(rawNumber),
      name: formData.fullName.trim(),
      email: formData.email.trim(),
      password: formData.newPassword,
      role: "USER",
      hasBankAccount: false,
      accountStatus: "ACTIVE",
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(formData.fullName.trim())}`,
      createdAt: new Date().toISOString(),
      currency: "INR",
      tier: "AURA STANDARD"
    };

    await registerUserInStore(newUser);
    createWebsiteSession(newUser);
    setIsAuthenticating(false);
    onLoginSuccess(newUser);
  };

  // Modern Blue Theme Input Style
  const inputStyle = {
    width: '100%',
    padding: '12px',
    border: '1px solid #7c93b6',
    borderRadius: '24px',
    outline: 'none',
    fontSize: '14px',
    color: '#000000',
    background: 'transparent',
    marginTop: '6px'
  };

  const labelStyle = {
    fontSize: '12px',
    fontWeight: '500',
    color: '#1f2937',
    display: 'block'
  };

  const btnPrimary = {
    background: '#000000',
    color: '#ffffff',
    border: 'none',
    padding: '12px 32px',
    borderRadius: '999px',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '13px',
    letterSpacing: '1px',
    marginTop: '24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px'
  };

  const btnSecondary = {
    ...btnPrimary,
    background: 'transparent',
    color: '#000000',
    border: '1px solid #000000',
    marginTop: '12px'
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      display: 'flex', background: '#a3bce2', color: '#000000', fontFamily: 'Inter, sans-serif',
      padding: '80px 5%', gap: '60px', flexWrap: 'wrap', overflowY: 'auto'
    }}>
      {/* Left Text Area / Animation */}
      <div style={{ flex: '1 1 300px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start' }}>
        <style>
          {`
            @keyframes namasteFloat {
              0% { transform: translateY(0px); }
              50% { transform: translateY(-8px); }
              100% { transform: translateY(0px); }
            }
          `}
        </style>
        <img 
          src="/namaste_couple.jpg" 
          alt="Namaste Greeting" 
          style={{ width: '400px', height: 'auto', animation: 'namasteFloat 4s ease-in-out infinite', mixBlendMode: 'multiply', marginBottom: '8px', borderRadius: '24px' }}
        />
        <h2 style={{ fontSize: '42px', fontWeight: '500', lineHeight: 1.1, marginBottom: '16px', color: '#000', letterSpacing: '-1px' }}>
          Welcome back to<br />Aura Banking
        </h2>
        <p style={{ fontSize: '15px', color: '#1f2937', lineHeight: 1.6, maxWidth: '400px' }}>
          Please verify your identity using your secure credentials or mobile device to access your autonomous financial copilot.
        </p>
      </div>

      {/* Right Content Area (Form) */}
      <div style={{
        flex: 1, maxWidth: '600px', display: 'flex', flexDirection: 'column',
        justifyContent: 'center', alignItems: 'center', padding: '20px', overflowY: 'auto'
      }}>
        <div style={{ width: '100%', maxWidth: '400px', margin: 'auto', textAlign: 'center' }}>
          
          {/* Welcome Stage */}
          {stage === 'welcome' && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ width: '64px', height: '64px', background: '#000', color: '#fff', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28px', fontWeight: '700', margin: '0 auto 24px' }}>
                A
              </div>
              <h2 style={{ fontSize: '28px', fontWeight: '600', letterSpacing: '-0.5px' }}>Welcome to Aura</h2>
              <p style={{ color: '#4b5563', marginTop: '12px', fontSize: '15px', lineHeight: 1.5 }}>
                Enter the next generation of autonomous banking. Please verify your identity to continue.
              </p>
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <button style={{...btnPrimary, width: 'auto', whiteSpace: 'nowrap', padding: '12px 24px'}} onClick={() => setStage('phone_lookup')}>
                  Verify Mobile Number <ArrowRight size={18} />
                </button>
              </div>
            </div>
          )}

          {/* Phone Lookup Stage */}
          {stage === 'phone_lookup' && (
            <form onSubmit={handleCheckPhoneNumber} style={{ textAlign: 'left' }}>
              <style>
                {`
                  .phone-input-wrapper {
                    display: flex;
                    align-items: center;
                    border: 1px solid #7c93b6;
                    border-radius: 24px;
                    transition: all 0.2s ease;
                    background: transparent;
                    overflow: hidden;
                    margin-top: 6px;
                  }
                  .phone-input-wrapper:hover, .phone-input-wrapper:focus-within {
                    border-color: #000000;
                    box-shadow: 0 0 0 2px rgba(0,0,0,0.1);
                    background: rgba(255, 255, 255, 0.4);
                  }
                `}
              </style>
              
              <button 
                type="button" 
                onClick={() => setStage('welcome')} 
                style={{ background: 'none', border: 'none', color: '#4b5563', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px', fontSize: '13px', fontWeight: '600', padding: 0, marginBottom: '24px' }}
              >
                <ArrowLeft size={16} /> Back
              </button>
              
              <h2 style={{ fontSize: '26px', fontWeight: '600', letterSpacing: '-0.5px', marginBottom: '8px', textAlign: 'center' }}>Log In or Register</h2>
              <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '32px', textAlign: 'center' }}>
                Enter your mobile number to securely access your Aura Banking account.
              </p>

              {sessionExpiredNotice && (
                <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#b91c1c', padding: '12px', borderRadius: '12px', fontSize: '13px', marginBottom: '24px' }}>
                  Your session expired for security reasons. Please log in again.
                </div>
              )}

              <div>
                <label style={labelStyle}>Phone Number</label>
                <div className="phone-input-wrapper">
                  <select 
                    value={countryCode} onChange={(e) => setCountryCode(e.target.value)}
                    style={{ background: 'transparent', border: 'none', padding: '12px 0 12px 16px', fontSize: '14px', color: '#000', outline: 'none', cursor: 'pointer' }}
                  >
                    <option value="+91">+91 (IN)</option>
                  </select>
                  <div style={{ width: '1px', height: '24px', background: '#7c93b6', margin: '0 8px' }}></div>
                  <input
                    type="tel"
                    placeholder="e.g. 555 019 283"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', padding: '12px 16px 12px 0', fontSize: '14px', color: '#000' }}
                  />
                </div>
              </div>
              
              {phoneLookupError && <div style={{ color: '#ef4444', fontSize: '13px', marginTop: '12px', textAlign: 'center' }}>{phoneLookupError}</div>}

              <div style={{ display: 'flex', justifyContent: 'center', marginTop: '24px' }}>
                <button type="submit" style={{...btnPrimary, marginTop: '0', width: '200px'}} disabled={isSearchingPhone}>
                  {isSearchingPhone ? "Verifying..." : "Continue"}
                </button>
              </div>
            </form>
          )}

          {/* Password Entry Stage */}
          {stage === 'enter_password' && (
            <form onSubmit={handlePasswordSubmit} style={{ textAlign: 'left' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
                <img src={matchedUser?.avatarUrl || "https://api.dicebear.com/7.x/bottts/svg?seed=Aura"} alt="Avatar" style={{ width: '48px', height: '48px', borderRadius: '50%' }} />
                <div>
                  <h2 style={{ fontSize: '20px', fontWeight: '600' }}>Welcome back, {matchedUser?.name?.split(' ')[0]}</h2>
                  <p style={{ color: '#4b5563', fontSize: '13px' }}>{countryCode} {phoneNumber}</p>
                </div>
              </div>

              <label style={labelStyle}>Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
                  style={inputStyle}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{ position: 'absolute', right: '16px', top: '21px', background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280' }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>

              {loginError && <div style={{ color: '#ef4444', fontSize: '13px', marginTop: '12px' }}>{loginError}</div>}

              <div style={{ textAlign: 'right', marginTop: '12px' }}>
                <button type="button" onClick={handleForgotPassword} style={{ background: 'none', border: 'none', color: '#4b5563', fontSize: '13px', textDecoration: 'underline', cursor: 'pointer' }}>
                  Forgot Password?
                </button>
              </div>

              <button type="submit" style={btnPrimary} disabled={isAuthenticating}>
                {isAuthenticating ? "Authenticating..." : "Log In"}
              </button>
              <button type="button" style={btnSecondary} onClick={() => setStage('phone_lookup')}>
                Switch Account
              </button>
            </form>
          )}

          {/* Multi Device Prompt Stage */}
          {stage === 'multi_device_prompt' && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ marginBottom: '24px', display: 'flex', justifyContent: 'center' }}>
                <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: '#fffbeb', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#f59e0b' }}>
                  <ShieldCheck size={32} />
                </div>
              </div>
              <h2 style={{ fontSize: '24px', fontWeight: '700', marginBottom: '12px' }}>Active Session Detected</h2>
              <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '24px', lineHeight: 1.5 }}>
                Your account is already logged into another device. For your security, you can only have one active session at a time.
                <br/><br/>
                Would you like to log out of the other device and log in here?
              </p>

              <button 
                onClick={() => {
                  createWebsiteSession(matchedUser);
                  onLoginSuccess(matchedUser);
                }} 
                style={btnPrimary}
              >
                Log Out Other Device & Continue
              </button>
              <button 
                onClick={() => setStage('phone_lookup')} 
                style={btnSecondary}
              >
                Cancel Login
              </button>
            </div>
          )}

          {/* Forgot Password Stage */}
          {stage === 'forgot_password' && (
            <div style={{ textAlign: 'left' }}>
              <h2 style={{ fontSize: '26px', fontWeight: '600', letterSpacing: '-0.5px', marginBottom: '8px' }}>Reset Password</h2>
              <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '24px', lineHeight: 1.5 }}>
                A request has been sent to the System Admin. Please contact the Admin to receive your 6-digit Reset PIN.
              </p>

              {resetError && <div style={{ color: '#ef4444', fontSize: '13px', marginBottom: '16px' }}>{resetError}</div>}
              {resetSuccess && <div style={{ color: '#10b981', fontSize: '13px', marginBottom: '16px' }}>{resetSuccess}</div>}

              <label style={labelStyle}>Admin Reset PIN</label>
              <input
                type="text"
                placeholder="6-digit PIN"
                value={resetPinInput}
                onChange={(e) => setResetPinInput(e.target.value)}
                style={{ ...inputStyle, marginBottom: '16px' }}
              />

              <label style={labelStyle}>New Password / MPIN</label>
              <input
                type="tel"
                placeholder="New secure password or MPIN"
                value={newResetPassword}
                onChange={(e) => setNewResetPassword(e.target.value)}
                style={{ ...inputStyle, WebkitTextSecurity: 'disc' }}
              />

              <button style={btnPrimary} onClick={handleResetPasswordSubmit}>Verify PIN & Reset</button>
              <button style={btnSecondary} onClick={() => setStage('enter_password')}>Go Back</button>
            </div>
          )}

          {/* Create Profile Stage */}
          {stage === 'create_profile' && (
            <form onSubmit={handleCreateProfileSubmit} style={{ textAlign: 'left' }}>
              <h2 style={{ fontSize: '26px', fontWeight: '600', letterSpacing: '-0.5px', marginBottom: '8px' }}>Create Account</h2>
              <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '24px' }}>
                Linked to: <span style={{ fontWeight: '600', color: '#ffffff' }}>{countryCode} {phoneNumber}</span>
              </p>

              {regError && <div style={{ background: '#fef2f2', border: '1px solid #fecaca', color: '#b91c1c', padding: '12px', borderRadius: '12px', fontSize: '13px', marginBottom: '24px' }}>{regError}</div>}

              <div style={{ marginBottom: '16px' }}>
                <label style={labelStyle}>Full Legal Name</label>
                <input
                  type="text"
                  placeholder="e.g. Alexander Hamilton"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  style={inputStyle}
                />
                <div style={{ fontSize: '12px', marginTop: '6px', color: checks.fullName.isValid ? '#10b981' : '#6b7280' }}>
                  {checks.fullName.message}
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={labelStyle}>Email Address</label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  style={inputStyle}
                />
                <div style={{ fontSize: '12px', marginTop: '6px', color: checks.email.isValid ? '#10b981' : '#6b7280' }}>
                  {checks.email.message}
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={labelStyle}>Create Password</label>
                <input
                  type="tel"
                  placeholder="6+ chars"
                  value={formData.newPassword}
                  onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
                  style={{ ...inputStyle, WebkitTextSecurity: 'disc' }}
                />
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={labelStyle}>Confirm Password</label>
                <input
                  type="tel"
                  placeholder="Re-enter password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  style={{ ...inputStyle, WebkitTextSecurity: 'disc' }}
                />
              </div>

              <button type="submit" style={btnPrimary} disabled={isAuthenticating}>
                {isAuthenticating ? "Creating Profile..." : "Complete Registration"}
              </button>
              <button type="button" style={btnSecondary} onClick={() => setStage('phone_lookup')}>
                Change Phone Number
              </button>
            </form>
          )}

        </div>
        <div style={{ marginTop: 'auto' }} />
      </div>
    </div>
  );
};
